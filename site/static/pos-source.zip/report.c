#include <stdio.h>
#include "item.h"
#include "report.h"

void print_all(FILE *fp) {
    struct item it;
    int  count = 0;
    long total = 0;

    rewind(fp);
    printf("코드  상품명        단가  수량\n");
    printf("-------------------------------\n");

    // Task #2: fread()로 끝까지 읽어 출력하고 상품 종류 수, 총 재고 금액 계산 구현

    while (fread(&it, sizeof(it), 1, fp) == 1) {
        printf("%4d %10s %4d %2d\n", it.code, it.name, it.price, it.qty);
        count++;
        total += (long)it.price * it.qty;

    } //fread로 읽어서 상품 정보를 출력하고 한 줄 읽어서 출력할 때마다 count++를 통해 종류 수를 계산한  다음 total에서 전체 상품 가격과 수량을 계산하여 총 재고 금액을 계산함

    printf("-------------------------------\n");
    printf("상품 %d종, 총 재고 금액 %ld원\n", count, total);
}


