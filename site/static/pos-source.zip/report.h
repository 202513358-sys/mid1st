#include <stdio.h>

void print_all(FILE *fp);
