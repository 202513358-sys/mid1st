struct item {
        int code;
        char name[20];
        int price;
        int qty;
};

#define START_CODE 2001
