#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "item.h"
#include "report.h"

// Task #4: print_all() 함수를 report.c, report.h 로 분리 (copy 코드 분리 예제 참고)

//struct item {
    //int  code;
    //char name[20];
    //int  price;
    //int  qty;
//};

//#define START_CODE 2001 //코드가 2001부터 시작
//여기까지 item.h로 이동


void print_all(FILE *fp);
void task1_init(char *inputFile, char *outputFile);
void task2_print(char *binaryFile);
void task3_sell(char *binaryFile, int code);

void task1_init(char *inputFile, char *outputFile) {
    FILE *fin = fopen(inputFile, "r");
    FILE *fout;
    struct item it;

    if (fin == NULL) {
        fprintf(stderr, "[파일 오류] %s: ", inputFile);
        perror("");
        return;
    }
    fout = fopen(outputFile, "wb");
    if (fout == NULL) {
        fprintf(stderr, "[파일 오류] %s: ", outputFile);
        perror("");
        fclose(fin);
        return;
    }

    // Task #1: fscanf()로 한 줄씩 읽고 fwrite()로 구조체 저장 구현

    while (fscanf(fin, "%d %19s %d %d", &it.code, it.name, &it.price, &it.qty) == 4)
	    fwrite(&it, sizeof(it), 1, fout); //블록단위로 저장 47p
					      

    fclose(fin);
    fclose(fout);


}


void task2_print(char *binaryFile) {

    // Task #2: 바이너리 파일을 열고 print_all()로 전체 데이터 출력 후 파일 닫기 구현
    FILE *fp = fopen(binaryFile, "rb"); //Task1에서 만든 바이너리 파일을 읽기 전용으로 열기

    if (fp == NULL) {
	    fprintf(stderr, "[파일 오류] %s: ", binaryFile);
	    perror("");
	    fclose(fp);
	    return;
    } //Task1과 동일한 예외처리

    //printf("%s 열기 성공, print_all 호출\n", binaryFile);
    print_all(fp);
    fclose(fp);

}


void task3_sell(char *binaryFile, int code) {
    FILE *fp = fopen(binaryFile, "rb+");
    struct item it;
    long offset; //시작 위치
    int  n; //판매 수량

    if (fp == NULL) {
        fprintf(stderr, "[파일 오류] %s: ", binaryFile);
        perror("");
        return;
    }

    printf("판매 전 데이터:\n");
    print_all(fp);

    // Task #3: fseek()로 상품 위치 이동, 판매 수량 입력, 재고 확인 후 fwrite()로 수정 구현

    if (code < START_CODE) {
	printf("[상품 없음] 코드 %d에 해당하는 상품이 없습니다.\n", code);
	fclose(fp);
	return;
    } //시작 코드보다 작은 상품 코드면 종료

    offset = (code - START_CODE) * sizeof(it); //시작 위치 계산

    if (fseek(fp, offset, SEEK_SET) !=0 || fread(&it, sizeof(it), 1, fp) !=1 || it.code != code) {
	printf("[상품 없음] 코드 %d에 해당하는 상품이 없습니다.\n", code);
	fclose(fp);
	return;
    } //offset에서 계산한 위치로 이동해서 상품 코드를 확인하고 코드가 일치하지 않으면 종료

    printf("몇 개 파시겠습니까?");
    if (scanf("%d", &n) !=1 || n <= 0) {
	printf("[입력 오류] 판매 수량은 1이상의 정수로 입력해 주세요.\n");
	fclose(fp);
	return;
    } //수량이 0이하면 종료

    if (n > it.qty) {
        printf("[재고 부족] 현재 재고 %d개보다 많은 %d개는 판매할 수 없습니다.\n", it.qty, n);
        fclose(fp);
        return;
    } //현재 재고보다 판매 수량이 많으면 종료

    it.qty -= n;
    fseek(fp, offset, SEEK_SET); //읽은 후 위치가 다음 상품으로 이동했기 때문에 다시 이동
    fwrite(&it, sizeof(it), 1, fp); 

    printf("\n판매 후 데이터:\n");
    print_all(fp);

    fclose(fp);
}

void task5_add(char *binaryFile, int code) { //sell과 동일코드
    FILE *fp = fopen(binaryFile, "rb+");
    struct item it;
    long offset; 
    int  n; 

    if (fp == NULL) {
        fprintf(stderr, "[파일 오류] %s: ", binaryFile);
        perror("");
        return;
    }

    printf("입고 전 데이터:\n");
    print_all(fp);

    if (code < START_CODE) {
        printf("[상품 없음] 코드 %d에 해당하는 상품이 없습니다.\n", code);
        fclose(fp);
        return;
    } //시작 코드보다 작은 상품 코드면 종료

    offset = (code - START_CODE) * sizeof(it); //시작 위치 계산

    if (fseek(fp, offset, SEEK_SET) !=0 || fread(&it, sizeof(it), 1, fp) !=1 || it.code != code) {
        printf("[상품 없음] 코드 %d에 해당하는 상품이 없습니다.\n", code);
        fclose(fp);
        return;
    } //offset에서 계산한 위치로 이동해서 상품 코드를 확인하고 코드가 일치하지 않으면 종료

    printf("몇 개 입고하시겠습니까?");
    if (scanf("%d", &n) !=1 || n <= 0) {
        printf("[입력 오류] 입고 수량은 1이상의 정수로 입력해 주세요.\n");
        fclose(fp);
        return;
    } //수량이 0이하면 종료

    it.qty += n;
    fseek(fp, offset, SEEK_SET); //읽은 후 위치가 다음 상품으로 이동했기 때문에 다시 이동
    fwrite(&it, sizeof(it), 1, fp);

    printf("\n입고 후 데이터:\n");
    print_all(fp);

    fclose(fp);
}

int main(int argc, char *argv[]) {
    if (argc < 2) {
        printf("[사용법] %s [init|print|sell] [인수...]\n", argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "init") == 0) {
        if (argc != 4) {
            printf("[사용법] %s init items.txt items_binary.dat\n", argv[0]);
            return 1;
        }
        task1_init(argv[2], argv[3]);
    }
    else if (strcmp(argv[1], "print") == 0) {
        if (argc != 3) {
            printf("[사용법] %s print items_binary.dat\n", argv[0]);
            return 1;
        }
        task2_print(argv[2]);
    }
    else if (strcmp(argv[1], "sell") == 0) {
        if (argc != 4) {
            printf("[사용법] %s sell items_binary.dat CODE\n", argv[0]);
            return 1;
        }
        task3_sell(argv[2], atoi(argv[3]));
    }

    else if (strcmp(argv[1], "add") == 0) {
        if (argc != 4) {
            printf("[사용법] %s sell items_binary.dat CODE\n", argv[0]);
            return 1;
        }
        task5_add(argv[2], atoi(argv[3]));
    }

    else {
        printf("[명령어 오류] 알 수 없는 명령어입니다: %s\n", argv[1]);
        return 1;
    }

    return 0;
}
